insert into suporte values(1, 'VHS');
insert into suporte values(2, 'DVD');
insert into suporte values(3, 'Blue-Ray');
insert into suporte values(4, 'CD');
insert into suporte values(5, 'MP3');
insert into suporte values(6, 'Spotify');
