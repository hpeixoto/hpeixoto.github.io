[1] Usando o SQLDeveloper, com a ligação à pdb (orclpdb1.localdomain) com o user system, correr o script 1-database.sql para criar o schema
hr. Será questionado qual a senha que pretende definir para o utilizador HR que será criado.

[2] Criar uma nova ligação no SQLDeveloper com as credenciais criadas no passo anterior.
		user: HR
		senha: ???????
		host: localhost
		servicename: orclpdb1.localdomain

[3] Copiar o conteúdo do ficheiro 2-script.sql para a worksheet do SQLDeveloper, selecionar e correr o script de uma
vez só. No final deverá ter todas as tabelas, dados, sequências, índices e restantes objetos corretamente criados.