insert into genero values (	1, 'Pop Rock');
insert into genero values (	2, 'K Pop');
insert into genero values (	3, 'Classica');
insert into genero values (	4, 'Heavy Metal');
insert into genero values (	5, 'Reagge');
