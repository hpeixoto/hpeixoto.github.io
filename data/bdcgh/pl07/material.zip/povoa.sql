delimiter $$
create function idade (dta  date) 
returns int
begin
		return TIMESTAMPDIFF(YEAR,dta,CURDATE());
end $$


---
insert into cod_postal  values ('4750-002','BARCELOS');
insert into cod_postal  values ('4700-001','BRAGA');
insert into cod_postal  values ('4700-002','BRAGA');
insert into cod_postal  values ('4700-003','BRAGA');
insert into cod_postal  values ('4700-004','BRAGA');
insert into cod_postal  values ('4700-005','BRAGA');

insert into especialidades values('OFT','Oftalmologia',50);
insert into especialidades values('CG','ClÌnica Geral',30);
insert into especialidades values('CAR','Cardiologia',90);
insert into especialidades values('NEU','Neurologia',70);

insert into medicos values ('123456','José Maria','Rua de Cima','4700-001','1970-01-23','OFT','1990-02-23');
insert into medicos values ('223456','Antonio Pinto','Rua de Baixo 34','4700-003','1991-11-21','CG','1990-01-23');
insert into medicos values ('323456','Manuel Maria Neves','Rua de Sul 66','4700-002','1964-03-24','CG','1979-07-23');
insert into medicos values ('423456','Pedro Pinto Silva','Rua de Este 44','4750-002','1978-02-13','CAR','1980-01-23');
insert into medicos values ('523456','Marta Catarina','Rua de Cima 21','4700-001','1960-09-11','OFT','1971-05-23');

insert into pacientes values ('123456789','Manuel Marques','Rua de Cima 64','4700-001','1970-01-23');
insert into pacientes values ('223456789','Pedro Paulo','Rua de Sul 73','4700-002','1991-04-22');
insert into pacientes values ('323456789','Maria José Silva','Rua de Este 46','4700-005','2012-11-01');
insert into pacientes values ('423456789','José Manuel Marques','Rua de Oeste 27','4700-004','1970-09-26');
insert into pacientes values ('523456789','Jacinto Homem','Rua de Este 34','4750-002','1982-12-23');
insert into pacientes values ('623456789','Sara Catarina Costa','Rua de Sul 15','4750-002','1986-11-02');
insert into pacientes values ('723456789','José Carlos Moreira','Rua de Oeste 73','4700-004','1970-09-07');
insert into pacientes values ('823456789','Joana Silva','Rua de Este 44','4750-002','2010-04-03');
insert into pacientes values ('923456789','Rosa Maria Carvalho','Rua de Sul 53','4750-002','2001-11-13');


insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-01-23 14:30','123456','123456789',23);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-03-22 09:30','223456','223456789',21);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-03-21 14:30','223456','223456789',11);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-06-01 08:30','423456','123456789',13);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-06-13 15:30','423456','323456789',20);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-05-21 16:30','323456','323456789',33);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-04-27 17:30','223456','523456789',40);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-03-07 13:30','123456','123456789',20);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-02-27 14:30','123456','423456789',20);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-01-12 15:30','223456','223456789',23);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-02-11 11:30','223456','223456789',13);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-03-01 14:30','523456','623456789',13);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-09-30 14:30','223456','123456789',20);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-08-23 11:30','323456','623456789',28);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-01-23 15:30','123456','623456789',23);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-03-22 10:30','223456','723456789',21);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-03-21 15:30','223456','623456789',11);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-06-01 09:30','423456','623456789',13);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-06-13 16:30','423456','923456789',20);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2016-05-21 17:30','323456','923456789',33);
insert into consultas (data_hora,id_medico,id_paciente,preco) values ('2015-04-27 18:30','223456','823456789',40);