const express = require("express");
const cors = require("cors");
const { Pool } = require("pg");
const { v4: uuidv4 } = require("uuid");
const jdt = require("./jdt_analises.json");
const app = express();
const port = 5001;

app.use(
    cors({
        origin: "http://localhost:3000", // ou 5173 se usares Vite
        methods: ["GET", "POST"],
        allowedHeaders: ["Content-Type"],
    })
);
app.use(express.json());

// Conexão à base de dados
const pool = new Pool({
    user: "nextgen_user",
    host: "localhost",
    database: "pce_forms",
    password: "nextgen_password",
    port: 5432,
});

// Endpoint para guardar uma composição
app.post("/api/compositions", async (req, res) => {
    let { composition } = req.body;
    if (typeof composition === "string") {
      composition = JSON.parse(composition);
    }
      
    const id = uuidv4();
  
    try {
      await pool.query(
        "INSERT INTO public.composition VALUES ($1, $2)",
        [id, composition]
      );
      res.status(201).json({ message: "Guardado com sucesso!", id });
    } catch (err) {
      console.error("Erro ao guardar:", err);
      res.status(500).json({ error: "Erro ao guardar a composition" });
    }
});

// Iniciar servidor
app.listen(port, () => {
    console.log(`Backend a correr em http://localhost:${port}`);
});